using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

[RequireComponent(typeof(UIDocument))]
public class HowToPlay1 : MonoBehaviour
{
    Button btn_Exit;
    void Awake()
    {
        VisualElement root = GetComponent<UIDocument>().rootVisualElement;

        btn_Exit = root.Q<Button>("Exit");

        btn_Exit.clicked += ExitToMainMenu;

    }
    private void ExitToMainMenu()
    {
        Time.timeScale = 1;

        SceneManager.LoadScene(0);
    }
}
