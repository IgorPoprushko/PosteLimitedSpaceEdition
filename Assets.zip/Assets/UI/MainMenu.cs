using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;
using Project.Utils;
using System;

[RequireComponent(typeof(UIDocument))]
public class MainMenu : MonoBehaviour
{
    Button btn_Play;
    Button btn_Exit;
    Button btn_Settings, btn_Tut;
    public AudioClip debugMenuMusic;
    void Awake()
    {
        UnityEngine.Cursor.visible = true;
        AudioManager.Instance.PlayMusic(debugMenuMusic);

        VisualElement root = GetComponent<UIDocument>().rootVisualElement;

        btn_Exit = root.Q<Button>("Exit");
        btn_Play = root.Q<Button>("Play");
        btn_Settings = root.Q<Button>("Settings");
        btn_Tut = root.Q<Button>("Tut");

        btn_Exit.clicked += ExitApp;
        btn_Play.clicked += Play;
        btn_Settings.clicked += Settings;
        btn_Tut.clicked += Tut;

    }

    private void Tut() {
        SceneManager.LoadScene(5);
    }

    private void Play()
    {
        SceneManager.LoadScene(2);
    }
    private void ExitApp()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
    private void Settings()
    {
        SceneManager.LoadScene(1);
    }
}
