using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

[RequireComponent(typeof(UIDocument))]
public class ExitMenu : MonoBehaviour
{
    Button btn_Retry;
    Button btn_Exit;
    public AudioClip debugMenuMusic;
    void Awake()
    {
        Time.timeScale = 0;

        UnityEngine.Cursor.visible = true;

        VisualElement root = GetComponent<UIDocument>().rootVisualElement;

        btn_Exit = root.Q<Button>("Exit");
        btn_Retry = root.Q<Button>("Retry");

        btn_Exit.clicked += ExitToMainMenu;
        btn_Retry.clicked += Retry;

    }
    private void Retry()
    {
        Time.timeScale = 1;

        SceneManager.LoadScene(2);
    }
    private void ExitToMainMenu()
    {
        Time.timeScale = 1;

        SceneManager.LoadScene(0);
    }
}
