using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;
using Project.Utils;

[RequireComponent(typeof(UIDocument))]
public class SettingsMenu : MonoBehaviour
{
    Button btn_Menu, btn_Reset, btn_Revert;
    Slider gv,mv,ev;
    private float gv_v, ev_v, mv_v;

    void Awake()
    {
        VisualElement root = GetComponent<UIDocument>().rootVisualElement;

        btn_Menu = root.Q<Button>("Menu");
        btn_Reset = root.Q<Button>("Reset");
        btn_Revert = root.Q<Button>("Revert");
        gv = root.Q<Slider>("GV");
        mv = root.Q<Slider>("MV");
        ev = root.Q<Slider>("EV");

        btn_Menu.clicked += Menu;
        btn_Reset.clicked += Resetrogress;
        btn_Revert.clicked += RevertAudioSettings;

        gv_v = AudioManager.Instance.GlobalVolume;
        ev_v = AudioManager.Instance.EffectsVolume;
        mv_v = AudioManager.Instance.MusicVolume;

        gv.value = gv_v;
        ev.value = ev_v;
        mv.value = mv_v;

        gv.RegisterValueChangedCallback((ChangeEvent<float> v) => {gv_v = v.newValue; AudioManager.Instance.SetGlobalVolume(v.newValue); });
        ev.RegisterValueChangedCallback((ChangeEvent<float> v) => {ev_v = v.newValue; AudioManager.Instance.SetEffectsVolume(v.newValue); });
        mv.RegisterValueChangedCallback((ChangeEvent<float> v) => {mv_v = v.newValue; AudioManager.Instance.SetMusicVolume(v.newValue); });
    }
    private void Menu()
    {
        PlayerPrefs.SetFloat("global_volume", gv_v);
        PlayerPrefs.SetFloat("effects_volume", ev_v);
        PlayerPrefs.SetFloat("music_volume", mv_v);

        SceneManager.LoadScene(0);
    }
    private void Resetrogress()
    {
    }
    private void RevertAudioSettings()
    {
        gv_v = 0.5f;
        ev_v = 0.5f;
        mv_v = 0.5f;

        gv.value = gv_v;
        ev.value = ev_v;
        mv.value = mv_v;

        PlayerPrefs.SetFloat("global_volume", 0.5f);
        PlayerPrefs.SetFloat("effects_volume", 0.5f);
        PlayerPrefs.SetFloat("music_volume", 0.5f);

        AudioManager.Instance.SetEffectsVolume(0.5f);
        AudioManager.Instance.SetMusicVolume(0.5f);
        AudioManager.Instance.SetGlobalVolume(0.5f);
    }
}
