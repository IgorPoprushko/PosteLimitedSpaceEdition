using UnityEngine;

namespace Project.Utils
{
    public class Singleton<T> : MonoBehaviour where T : Component
    {
        protected virtual bool m_dontDestroyOnLoad { get; } = true;

        private static T m_instance = null;
        private static object m_lock = new();

        public static bool HasInstance { get => m_instance != null; }
        public static T Instance
        {
            get
            {
                lock (m_lock)
                {
                    if (m_instance == null)
                    {

                        SetupInstance();
                    }
                }
                return m_instance;
            }
        }

        /// <summary>
        /// Creates instance of the singleton.
        /// </summary>
        public static void SetupInstance()
        {
            GameObject gameObj = new(typeof(T).Name);
            gameObj.AddComponent<T>();
        }

        /// <summary>
        /// Awake doesn't stop execution even if gameobject will be destroyed later, unlike <seealso cref="SafeAwake">SafeAwake</seealso>
        /// </summary>
        protected void Awake()
        {
            RemoveDuplicatesAndSetInstance();
        }

        protected void OnDestroy()
        {
            if (m_instance == this)
                SafeDestroy();
        }

        /// <summary>
        /// Would be called ONLY on singleton instance gameobject, unlike <seealso cref="Awake">Awake</seealso>
        /// </summary>
        protected virtual void SafeAwake() { }

        /// <summary>
        /// Would be called ONLY on singleton instance gameobject, unlike <seealso cref="OnDestroy">OnDestroy</seealso>
        /// </summary>
        protected virtual void SafeDestroy() { }

        private void RemoveDuplicatesAndSetInstance()
        {
            if (m_instance != null && m_instance != this as T)
            {
                Destroy(gameObject);
                return;
            }
            else if (m_instance == null)
            {
                m_instance = this as T;
                if(m_dontDestroyOnLoad)
                    DontDestroyOnLoad(gameObject);
                SafeAwake();
            }
        }
    }
}