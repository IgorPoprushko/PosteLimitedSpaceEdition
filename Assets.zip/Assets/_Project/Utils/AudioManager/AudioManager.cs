using System;
using UnityEngine;
using UnityEngine.Events;
using Project.Utils.MyAudio;

namespace Project.Utils
{
    public class AudioManager : Singleton<AudioManager>
    {
        [SerializeField] private AudioSource m_musicSource;
        [SerializeField] private AudioSource m_effectsSource;

        public UnityEvent<float> OnEffectsChangeVolume = new();

        public float GlobalVolume { get { return AudioListener.volume; } }
        public float MusicVolume { get { return m_musicSource.volume; } }
        public float EffectsVolume { get { return m_effectsSource.volume; } }

        protected override void SafeAwake()
        {
            if (m_musicSource == null)
                m_musicSource = gameObject.AddComponent<AudioSource>();
            if (m_effectsSource == null)
                m_effectsSource = gameObject.AddComponent<AudioSource>();

            AudioListener.volume = PlayerPrefs.GetFloat("global_volume", 0.5f);
            m_effectsSource.volume = PlayerPrefs.GetFloat("effects_volume", 0.5f);
            m_musicSource.volume = PlayerPrefs.GetFloat("music_volume", 0.5f);
        }
        public void PlayEffect(AudioClip clip)
        {
            m_effectsSource.PlayOneShot(clip);
        }
        public void PlayEffect(AudioClip clip, Vector3 position)
        {
            AudioSourcePool.Instance.Get().PlayAtPosition(clip, position);
        }
        public void PlayMusic(AudioClip clip)
        {
            m_musicSource.clip = clip;
            m_musicSource.Play();
        }

        public void SetEffectsVolume(float volume)
        {
            m_effectsSource.volume = volume;
            OnEffectsChangeVolume.Invoke(volume);
        }
        public void SetMusicVolume(float volume)
        {
            m_musicSource.volume = volume;
        }
        public void SetGlobalVolume(float volume)
        {
            AudioListener.volume = volume;
        }

    }

    namespace MyAudio
    {
        class AudioSourcePool : SingletonPoolBase<AudioSourcePool, AudioSourceControl>
        {
            protected override bool m_dontDestroyOnLoad => false;
            protected override bool CollectionCheck => false;
            protected override int DefaultCapacity => 5;
            protected override int MaxSize => 25;
            protected override AudioSourceControl CreateEntity()
            {
                return new GameObject("PositionedAudioSource", new[] { typeof(AudioSourceControl) }).GetComponent<AudioSourceControl>();
            }
            protected override Action<AudioSourceControl> OnEntityGet => (AudioSourceControl i) => { i.gameObject.SetActive(true); };
        }
        [RequireComponent(typeof(AudioSource))]
        class AudioSourceControl : MonoBehaviour, IReleasable
        {
            private AudioSource m_audioSource;

            private bool m_isActive = false;
            private float m_releaseTime;

            private void Awake()
            {
                m_audioSource = GetComponent<AudioSource>();
                AudioManager.Instance.OnEffectsChangeVolume.AddListener(ChangeVolume);
                m_audioSource.volume = AudioManager.Instance.EffectsVolume;
            }
            private void ChangeVolume(float volume)
            {
                m_audioSource.volume = volume;
            }

            public void PlayAtPosition(AudioClip clip, Vector3 position)
            {
                m_isActive = true;
                m_releaseTime = Time.timeSinceLevelLoad + clip.length;
                transform.position = position;
                m_audioSource.clip = clip;
                m_audioSource.Play();
            }
            private void Update()
            {
                if (m_isActive)
                {
                    if (Time.timeSinceLevelLoad >= m_releaseTime)
                    {
                        Release();
                    }
                }
            }


            public void Release()
            {
                m_isActive = false;
                gameObject.SetActive(false);
                AudioSourcePool.Instance.ReleaseEntity(this);
            }
        }
    }
}