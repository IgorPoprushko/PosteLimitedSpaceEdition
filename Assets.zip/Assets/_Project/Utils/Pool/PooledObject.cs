using UnityEngine;

public interface IReleasable
{    
    void Release();
}
public abstract class PooledObjectBase : MonoBehaviour, IReleasable
{
    public abstract void Release();
}