using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;
using Project.Utils;
using static Project.Input.MyActions;

namespace Project.Input
{
    public class InputManager : Singleton<InputManager>, IPlayerActions
    {
        private MyActions m_myActions;

        public UnityEvent<Vector2> MoveInput = new();
        public UnityEvent<float> RotateInput = new();
        public UnityEvent<Vector2> MouseMoving = new();

        //public UnityEvent<bool> Fire1 = new(), Fire2 = new();
        public UnityEvent Interact = new();
        public UnityEvent Pause = new();

        protected override void SafeAwake()
        {
            m_myActions = new MyActions();
            m_myActions.Player.Enable();
            m_myActions.Player.AddCallbacks(this);
        }

        public void OnCancel(InputAction.CallbackContext context)
        {
            if (context.phase == InputActionPhase.Started)
                Pause?.Invoke();
        }

        //public void OnFire1(InputAction.CallbackContext context)
        //{
        //    if(context.phase == InputActionPhase.Started || context.phase == InputActionPhase.Canceled)
        //    Fire1?.Invoke(context.phase == InputActionPhase.Started);
        //}
        //public void OnFire2(InputAction.CallbackContext context)
        //{
        //    if(context.phase == InputActionPhase.Started)
        //        Fire2?.Invoke(context.phase == InputActionPhase.Started);
        //}
        //public void OnReload(InputAction.CallbackContext context)
        //{
        //    if (context.phase == InputActionPhase.Started)
        //        Reload?.Invoke();
        //}

        public void OnMousePos(InputAction.CallbackContext context)
        {
            //Debug.Log((context.ReadValue<Vector2>() - new Vector2(Screen.width / 2, Screen.height / 2)).normalized);
            MouseMoving.Invoke(context.ReadValue<Vector2>());
            
        }

        public void OnMove(InputAction.CallbackContext context)
        {

            MoveInput.Invoke(context.ReadValue<Vector2>());
        }

        public void OnInteract(InputAction.CallbackContext context)
        {
            if (context.phase == InputActionPhase.Started)
                Interact?.Invoke();
        }

        public void OnRotate(InputAction.CallbackContext context)
        {
            RotateInput.Invoke(context.ReadValue<float>());
        }
    }
}