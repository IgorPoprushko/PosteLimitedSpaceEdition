using UnityEngine;

[CreateAssetMenu(fileName = "Level_0", menuName = "Create Level")]
public class LevelSO : ScriptableObject
{
    [field: SerializeField] public uint PackageAmount { get; private set; }
    [field: SerializeField] public uint HealthAmount { get; private set; }
    [field: SerializeField] public uint SecondsToSendPackage { get; private set; }
    [field: SerializeField] public Vector2 SpawnPoint { get; private set; }
    [field: SerializeField] public AnimationCurve SpawnRate { get; private set; }
    [field: SerializeField] public Vector2 SendPoint { get; private set; }
    [field: SerializeField] public AnimationCurve PickupRate { get; private set; }

    //[field: SerializeField] public bool IsFragile { get; private set; }

}