using UnityEditor;
using UnityEngine;

[CreateAssetMenu(fileName = "Package_0", menuName = "Create Package")]
public class PackageSO : ScriptableObject
{
    public PackageType Type { get; private set; }
    [field: SerializeField] public Vector2 Size { get; private set; }
    [field: SerializeField] public Vector2 NumberPos { get; private set; }
    [field: SerializeField] public Vector2 TypePos { get; private set; }
    [field: SerializeField] public float Mass { get; private set; }

    [field: SerializeField] public Vector2[] ColliderData;

#if UNITY_EDITOR
    [ContextMenu("Set Collider From Size")]
    public void SetColFromSize()
    {

        if (Size.x > 0 && Size.y > 0)
        {

            float tempX = Size.x / 2;
            float tempY = Size.y / 2;

            Undo.RecordObject(this, "ColliderData");
            ColliderData = new Vector2[4] { new Vector2(tempX, tempY), new Vector2(tempX, -tempY), new Vector2(-tempX, -tempY), new Vector2(-tempX, tempY) };
            Debug.Log("Collider was set");
        }
        else
        {
            Debug.LogError("Size can't be less then 0");
        }


    }
#endif

}
public enum PackageType {
    Default,
    Fragile,
    Freeze
}
