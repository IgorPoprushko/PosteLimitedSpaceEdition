using TMPro;
using UnityEngine;

[SelectionBase]
public class UnsortedPackagesVisual : MonoBehaviour
{
    public TextMeshProUGUI text;
    void Awake()
    {
        Logick2.Instance.OnChange.AddListener(UpdateVisual);
        UpdateVisual();
    }

    private void UpdateVisual()
    {
        text.text = $"{Logick2.Instance.UnsortedPackages}/{Logick2.Instance.MAXUnsortedPackages} Unsorted";
    }
}
