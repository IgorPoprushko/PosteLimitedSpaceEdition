using TMPro;
using UnityEngine;

[RequireComponent(typeof(Package))]
public class PackageVisual : MonoBehaviour
{
    private Package m_package;

    [SerializeField] private SpriteRenderer m_background;
    [SerializeField] private SpriteRenderer m_tape;
    [SerializeField] private SpriteRenderer m_fragile;


    [SerializeField] private Transform m_numberTransform;
    [SerializeField] private TextMeshPro m_number;

    private void Awake()
    {
        m_package = GetComponent<Package>();
        m_package.OnInit.AddListener(Init);
    }
    public void Init()
    {
        PackageSO data = m_package.Data;

        m_background.size = data.Size;
        m_tape.size = new Vector2(1, data.Size.y);


        m_numberTransform.localPosition = data.NumberPos;
        m_number.text = m_package.Id.ToString();
    }
}
