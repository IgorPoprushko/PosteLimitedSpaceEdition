using System;
using UnityEngine;
using UnityEngine.Events;

[RequireComponent(typeof(PolygonCollider2D))]

[SelectionBase]
public class Package : PooledObjectBase
{
    public uint Id { get; protected set; }

    public PackageSO Data { get; protected set; }
    public UnityEvent OnInit = new();

    public Rigidbody2D Rb { get; private set; }
    private PolygonCollider2D m_col;

    public event Action<Package> RemoveCallback;
    [SerializeField] private LayerMask m_playerMask;
    [SerializeField] private LayerMask m_defauult;

    private void Awake()
    {
        Rb = GetComponent<Rigidbody2D>();
        m_col = GetComponent<PolygonCollider2D>();
    }

    public void OnCollisionEnter2D(Collision2D collision) // 
    {
    }

    public override void Release()
    {
        RemoveCallback?.Invoke(this);
        PackagePool.Instance.ReleaseEntity(this);
    }

    public void Pickup(Transform par)
    {
        if(gameObject.layer == 7)
            Logick2.Instance.RemoveUnsortedPackage();

        transform.SetParent(par);
        gameObject.layer = 8;
        Rb.simulated = false;
        RemoveCallback?.Invoke(this);
    }
    public void Place(Transform par)
    {
        transform.SetParent(par);
        gameObject.layer = 8;
        Rb.simulated = true;

    }
    public void Place2(Transform par)
    {
        transform.SetParent(par);
        Rb.simulated = true;

    }
    public void PutDown()
    {
        Logick2.Instance.AddUnsortedPackage();
        gameObject.layer = 7;
        transform.parent = null;
        Rb.simulated = true;
    }

    public void Init(uint p_Id, PackageSO packageSO)
    {
        gameObject.layer = 7;
        Id = p_Id;
        Data = packageSO;

        m_col.points = Data.ColliderData;

        OnInit.Invoke();
    }
}
