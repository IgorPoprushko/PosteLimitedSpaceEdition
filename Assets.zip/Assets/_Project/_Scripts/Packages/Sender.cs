using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class Sender : MonoBehaviour
{
    private Package m_package;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.TryGetComponent(out m_package))
        {
            m_package.Release();
        }
    }
}
