using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class Loader : MonoBehaviour
{
    public Conveyor conveyor;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.TryGetComponent(out Package m_package))
        {
            conveyor.AddToEnd(m_package);
        }
    }
}
