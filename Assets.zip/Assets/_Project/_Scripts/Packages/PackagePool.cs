using UnityEngine;
using Project.Utils;
using System.Collections.Generic;

public class PackagePool : SingletonPoolBase<PackagePool,Package>
{
    protected override bool m_dontDestroyOnLoad => false;

    private List<PackageSO> m_allPackages;
    private Package m_prefab;

    protected override void SafeAwake()
    {
        base.SafeAwake();

        m_prefab = ResourcesHelper.Instance.PackagePrefab;
        m_allPackages = ResourcesHelper.Instance.GetAllPackageSO();
    }

    #region Create & Release
    protected override Package CreateEntity()
    {
        var package = Instantiate(m_prefab);
        return package;
    }
    protected override System.Action<Package> OnEntityRelease => OnRelease;
    private void OnRelease(Package p_package)
    {
        p_package.gameObject.SetActive(false);
        LogicManager.Instance.OnPackageSend(p_package.Id);
    }
    #endregion

    public void SendPackage(uint p_Id,Vector2 p_pos)
    {
        var package = Get();
        package.transform.SetPositionAndRotation(p_pos, Quaternion.identity);
        package.Init(p_Id, m_allPackages[Random.Range(0,m_allPackages.Count)]);
        package.gameObject.SetActive(true);
        Logick2.Instance.AddUnsortedPackage();
    }

}
