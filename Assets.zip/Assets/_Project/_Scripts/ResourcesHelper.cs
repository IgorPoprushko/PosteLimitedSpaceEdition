using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Project.Utils
{
    public class ResourcesHelper : Singleton<ResourcesHelper>
    {
        public Package PackagePrefab { get; private set; }
        public RequestElement RequestElement { get; private set; }

        protected override void SafeAwake()
        {
            PackagePrefab = Resources.Load<Package>("Prefabs/PackagePrefab");
            RequestElement = Resources.Load<RequestElement>("Prefabs/Request");
        }
        public List<PackageSO> GetAllPackageSO()
        {
            return Resources.LoadAll<PackageSO>("ScriptableObjects/Packages").ToList();
        }
        public List<LevelSO> GetAllLevelsSO()
        {
            return Resources.LoadAll<LevelSO>("ScriptableObjects/Levels").ToList();
        }
    }
}