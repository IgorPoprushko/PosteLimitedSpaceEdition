using System.Collections.Generic;
using UnityEngine;

public class GUIManager : MonoBehaviour
{
    public Transform requestBar;
    public Dictionary<uint, RequestElement> ProgressBars = new();

    public Transform healthBar;
    public GameObject healthPrefab;

    private void Awake()
    {
        LogicManager.Instance.addPackageRequest.AddListener(AddPackageRequest);
        LogicManager.Instance.sendRightPackage.AddListener(SendRightPackage);
        LogicManager.Instance.sendWrongPackage.AddListener(DecreaseHealth);
        LogicManager.Instance.Death.AddListener(Death);

        for (int i = 0; i < LogicManager.Instance.health; i++)
        {
            Instantiate(healthPrefab, healthBar);
        }
    }

    public void AddPackageRequest(uint id, float time)
    {
        var request = RequestElementPool.Instance.SetRequest(id, time, requestBar);

        ProgressBars.Add(id, request);
    }

    public void SendRightPackage(uint id)
    {
        ProgressBars[id].Release();
    }

    public void DecreaseHealth()
    {
        Destroy(healthBar.GetChild(0).gameObject);
    }

    public void Death()
    {
        healthBar.parent = null;
    }
}
