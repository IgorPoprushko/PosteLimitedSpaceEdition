using Project.Utils;
using UnityEngine;
using UnityEngine.Events;

public class Logick2 : Singleton<Logick2>
{
    protected override bool m_dontDestroyOnLoad => false;

    public UnityEvent OnChange = new();
    [field: SerializeField] public int MAXUnsortedPackages { get; private set; } = 8;
    [field: SerializeField] public int UnsortedPackages { get; private set; } = 0;

    protected override void SafeAwake()
    {
        OnChange.AddListener(Check);
        MAXUnsortedPackages = 8;
        UnsortedPackages = 0;
    }

    public void AddUnsortedPackage()
    {
        UnsortedPackages++;
        OnChange.Invoke();
    }
    public void RemoveUnsortedPackage()
    {
        UnsortedPackages--;
        OnChange.Invoke();
    }

    private void Check()
    {
        if (UnsortedPackages >= MAXUnsortedPackages)
        {
            LogicManager.Instance.RemoveHP();
            UnsortedPackages = 0;
        }
    }
}
