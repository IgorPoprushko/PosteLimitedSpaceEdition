using Project.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;
using Random = UnityEngine.Random;

public class LogicManager : Singleton<LogicManager>
{
    private bool start = false;
    private uint m_packegeId = 1;
    private float m_spawnActionTime = 0;
    private float m_pickupActionTime = 10;
    public List<uint> existingPackages = new();
    [SerializeField] private Dictionary<uint, float> requestedPackages = new();

    public uint maxHealth;
    public uint health;
    public int points = 0; 

    public UnityEvent SpawnPackage;
    public UnityEvent<uint,float> addPackageRequest;
    public UnityEvent<uint> sendRightPackage;
    public UnityEvent sendWrongPackage;
    public UnityEvent Death;
    public UnityEvent Win;

    public LevelSO levelSO;

    protected override void SafeAwake()
    {
        Init(ResourcesHelper.Instance.GetAllLevelsSO()[0]);
    }

    public void Init(LevelSO levelSO)
    {
        this.levelSO = levelSO;
        maxHealth = levelSO.HealthAmount;
        health = levelSO.HealthAmount;
        start = true;
    }

    private void FixedUpdate()
    {
        if (!start)
            return;
        if (levelSO.PackageAmount < m_packegeId && requestedPackages.Count <= 0 && existingPackages.Count <= 0)
        {
            start = false;
            SceneManager.LoadScene(4);
            return;
        }

        float tempTime = Time.timeSinceLevelLoad;

        if (tempTime > m_spawnActionTime)
        {
            m_spawnActionTime += levelSO.SpawnRate.Evaluate(m_packegeId/ levelSO.PackageAmount);
            PackagePool.Instance.SendPackage(m_packegeId, levelSO.SpawnPoint);
            existingPackages.Add(m_packegeId);
            m_packegeId++;
        }

        if (tempTime > m_pickupActionTime && existingPackages.Count>0)
        {
            m_pickupActionTime += (int)levelSO.PickupRate.Evaluate(m_packegeId / levelSO.PackageAmount);
            uint temp = existingPackages[Random.Range(0, existingPackages.Count )];
            tempTime = Time.timeSinceLevelLoad;
            requestedPackages.Add(temp, Time.timeSinceLevelLoad);
            existingPackages.Remove(temp);
            addPackageRequest.Invoke(temp, tempTime);
        }

        for (int i = 0; i < requestedPackages.Count; i++)
        {
            if ((Time.timeSinceLevelLoad - requestedPackages.ElementAt(i).Value) / levelSO.SecondsToSendPackage >= 1)
            {
                existingPackages.Add(requestedPackages.ElementAt(i).Key);
                requestedPackages.Remove(requestedPackages.ElementAt(i).Key);
                RemoveHP();
            }
        }
    }

    public void OnPackageSend(uint id)
    {
        if (requestedPackages.ContainsKey(id))
        {
            sendRightPackage.Invoke(id);
            points += (int)(Math.Max(1 - (Time.timeSinceLevelLoad- requestedPackages[id]) / levelSO.SecondsToSendPackage, 0)*100);

            requestedPackages.Remove(id);

            if(existingPackages.Contains(id))
                existingPackages.Remove(id);
        }
        else
        {
            RemoveHP();
        }
        Debug.Log("Package "+id+" is sended!");
    }

    public void RemoveHP()
    {
        health -= 1;
        sendWrongPackage.Invoke();
        if (health == 0)
        {
            SceneManager.LoadScene(3);
            start = false;
        }
    }

    protected override bool m_dontDestroyOnLoad => false;
}
