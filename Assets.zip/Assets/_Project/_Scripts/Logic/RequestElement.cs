using Project.Utils;
using TMPro;
using UnityEngine;
public class RequestElement : MonoBehaviour, IReleasable
{
    [SerializeField] TextMeshProUGUI numberText;
    [SerializeField] UnityEngine.UI.Image ProgressBar;

    private uint id;
    private float requestTime;

    private void FixedUpdate()
    {
        ProgressBar.fillAmount = 1 - (Time.timeSinceLevelLoad - requestTime) / LogicManager.Instance.levelSO.SecondsToSendPackage;
        if (ProgressBar.fillAmount <= 0)
        {
            Release();
        }
    }

    public void Init(uint id, float time)
    {
        this.id = id;
        requestTime = time;

        numberText.text = id.ToString();

    }

    public void Release()
    {
        RequestElementPool.Instance.ReleaseEntity(this);
        gameObject.SetActive(false);
    }
}

public class RequestElementPool : SingletonPoolBase<RequestElementPool, RequestElement>
{
    protected override bool m_dontDestroyOnLoad => false;

    protected override RequestElement CreateEntity()
    {
        return Instantiate(ResourcesHelper.Instance.RequestElement, Camera.main.transform.GetChild(0).GetChild(2));
    }

    public RequestElement SetRequest(uint id, float time, Transform tr)
    {
        RequestElement request = Get();
        request.gameObject.SetActive(true);

        request.transform.SetParent(tr);
        request.Init(id, time);

        return request;
    }
}