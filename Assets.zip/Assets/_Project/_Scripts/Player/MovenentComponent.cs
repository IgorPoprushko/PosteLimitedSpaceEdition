using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class MovenentComponent : MonoBehaviour
{
    //*/
    public bool InvertWhileMovingBack;

    private Vector2 m_inputDir;
    private Rigidbody2D m_rb;
    private float m_moveSpeed, m_rotateSpeed, m_multiplayer = 1;
    private bool m_isRunning;

    public void Init(float p_baseMoveSpeed, float p_baseRotSpeed)
    {
        m_rb = GetComponent<Rigidbody2D>();
        m_rb.centerOfMass = Vector2.zero;
        m_moveSpeed = p_baseMoveSpeed;
        m_rotateSpeed = p_baseRotSpeed;
        m_isRunning = true;
    }

    public void Override(float p_val)
    {
        m_multiplayer = p_val;
    }
    public void SetMoveInput(Vector2 moveDir)
    {
        m_inputDir = moveDir;
    }
    void FixedUpdate()
    {
        if (m_isRunning)
            HandleMovementAndRotation();
    }
    private float m_rot;
    private int m_invertor = 1;
    private void HandleMovementAndRotation()
    {
        if (m_inputDir.y != 0)
        {

            float deltaTime = Time.fixedDeltaTime;

            m_rb.MovePosition((m_moveSpeed * m_multiplayer * deltaTime) * (Vector2)(transform.up * m_inputDir.y) + m_rb.position);
        }
        if (m_inputDir.x != 0)
        {
            m_invertor = 1;
            if ((m_inputDir.y == -1) && InvertWhileMovingBack)
                m_invertor = -1;


            m_rot = (m_rb.rotation + -m_inputDir.x * m_rotateSpeed * m_multiplayer * m_invertor) % 360f;

            m_rb.MoveRotation(Quaternion.Euler(0f, 0f, m_rot));
        }
    }
}