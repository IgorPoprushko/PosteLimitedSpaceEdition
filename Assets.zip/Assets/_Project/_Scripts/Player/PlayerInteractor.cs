using Project.Utils;
using UnityEngine;
using UnityEngine.Events;

public class PlayerInteractor : MonoBehaviour
{
    [SerializeField] private LayerMask m_packageMask;
    [SerializeField] private float m_dist;
    [SerializeField] private AudioClip PickUpSound, PutDownErrorSound;
    [SerializeField] private Package m_pickedUpPackage;
    [SerializeField] private PolygonCollider2D m_pickedUpCollider;


    public UnityEvent OnInteract = new();
    public Package PickedUpPackage => m_pickedUpPackage;

    private RaycastHit2D m_hit;
    private Collider2D[] m_check;
    private WorkerBase m_worker;
    public void TryInteract() {
        if (m_pickedUpPackage != null)
        {
            m_check = Physics2D.OverlapBoxAll(m_pickedUpCollider.transform.position,m_pickedUpPackage.Data.Size, m_pickedUpPackage.Rb.rotation); // !!
            if (m_check.Length != 0)
            {
                foreach (var check in m_check)
                {
                    if (check.TryGetComponent(out m_worker))
                    {
                        if (m_worker.UserCanUse && m_worker.Work(m_pickedUpPackage))
                        {
                            Clear();
                        }
                        else
                        {
                            AudioManager.Instance.PlayEffect(PutDownErrorSound);
                            Debug.LogWarning("Cant Put Down");
                        }
                        return;
                    }
                }
            }
            m_pickedUpPackage.PutDown();
            Clear();
        }
        else
        {
            m_hit = Physics2D.Raycast(transform.position, transform.up, m_dist, m_packageMask);
            if (m_hit && m_hit.transform.TryGetComponent(out m_pickedUpPackage))
            {
                var t_transform = m_pickedUpPackage.transform;

                m_pickedUpPackage.Pickup(transform);

                m_pickedUpCollider.enabled = true;
                m_pickedUpCollider.transform.localPosition = t_transform.localPosition;
                m_pickedUpCollider.transform.localRotation = t_transform.localRotation;
                m_pickedUpCollider.SetPath(0, m_pickedUpPackage.Data.ColliderData);
                AudioManager.Instance.PlayEffect(PickUpSound);
                OnInteract.Invoke();
            }
        }
    }

    private void Clear()
    {
        m_pickedUpPackage = null;
        m_pickedUpCollider.enabled = false;
        OnInteract.Invoke();
    }
}
/*
    [SerializeField] LayerMask m_packageMask;
    [SerializeField] Transform m_leftPoint, m_rightPoint;
    [SerializeField] float m_dist;

    [SerializeField] private Package m_pickedUpPackage;
    [SerializeField] private Package m_tempL, m_tempR;
    void Update()
    {
        
    }

    private RaycastHit2D m_hitL, m_hitR;
    public void TryInteract() {
        if (m_pickedUpPackage != null)
        {
            m_pickedUpPackage.transform.parent = null;
            m_pickedUpPackage.PutDown();
            m_pickedUpPackage = null;
        }
        else
        {
            m_hitL = Physics2D.Raycast(m_leftPoint.position, transform.up, m_dist, m_packageMask);
            m_hitR = Physics2D.Raycast(m_rightPoint.position, transform.up, m_dist, m_packageMask);
            if (m_hitL && m_hitR && m_hitL.transform.TryGetComponent(out m_tempL) && m_hitR.transform.TryGetComponent(out m_tempR))
            {
                if ((m_tempL == m_tempR) && (m_hitL.normal == m_hitR.normal))
                {
                    m_pickedUpPackage = m_tempL;
                    m_pickedUpPackage.transform.SetParent(transform);
                    m_pickedUpPackage.Pickup();
                }
            }
        }
    }
/*/