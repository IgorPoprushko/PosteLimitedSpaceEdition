using UnityEngine;
using Project.Input;

[RequireComponent(typeof(MovenentComponent), typeof(Collider2D),typeof(PlayerInteractor))]
public class PlayerController : MonoBehaviour
{
    private MovenentComponent m_movenentComponent;
    private PlayerInteractor m_playerInteractor;
    void Awake()
    {
        m_movenentComponent = GetComponent<MovenentComponent>();
        m_playerInteractor = GetComponent<PlayerInteractor>();

        m_movenentComponent.Init(5f, 4.5f);
        InputManager.Instance.MoveInput.AddListener(m_movenentComponent.SetMoveInput);

        InputManager.Instance.Interact.AddListener(m_playerInteractor.TryInteract);
        m_playerInteractor.OnInteract.AddListener(OnPickUp);
    }

    private void OnPickUp()
    {
        m_movenentComponent.Override(
            (m_playerInteractor.PickedUpPackage == null) ? 
            1f 
            :
            Mathf.Clamp(1 - (m_playerInteractor.PickedUpPackage.Data.Mass / 200), 0.2f, 1f)
            );
    }
}