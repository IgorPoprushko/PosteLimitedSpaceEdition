using System;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

[RequireComponent(typeof(BoxCollider2D))]
public class Conveyor : WorkerBase
{
    [SerializeField] float m_dirNSpeed;

    [SerializeField] float REnd, LEnd;
    [SerializeField] LayerMask m_checkMask;
    [SerializeField] bool m_forUser;
    [SerializeField] bool SimpleCheck;

    private object m_lock = new();


    [SerializeField] private List<ItemOnConveyor> m_items = new();
    [Serializable] private class ItemOnConveyor
    {
        public float Pos;
        public float OffsetHor;
        public float OffsetVer;

        public Package Pack;

        public void UpdatePos() {
            Pos = Pack.transform.localPosition.x;
        }
    }

    private float m_end;
    private float m_start;
    private bool m_RtL;

    private void Awake()
    {
        UserCanUse = m_forUser;
        m_RtL = m_dirNSpeed < 0;
        m_end = (m_RtL) ? LEnd : REnd;
        m_start = (m_RtL) ? REnd : LEnd; 
    }

    private RaycastHit2D m_check1, m_check2, m_check0;
    private bool m_hasObst;

    private void FixedUpdate()
    {
        lock (m_lock)
        {
            if (m_items.Count <= 0)
                return;
            float delta = Time.fixedDeltaTime;
            float atm = m_dirNSpeed * delta;

            if (SimpleCheck)
            {
                for (int i = 0; i < m_items.Count; i++)
                {
                    var item = m_items[i];
                    switch (i)
                    {
                        case 0:
                            if ((m_RtL) ? item.Pos + atm > m_end : item.Pos + atm < m_end)
                                item.Pack.transform.localPosition += new Vector3(atm, 0f);
                            else
                                item.Pack.transform.localPosition = new Vector3(m_end, 0f);
                            break;
                        default:

                            var prevItem = m_items[i - 1];
                            float localEnd = (prevItem.Pos + ((m_RtL) ? prevItem.OffsetHor : -prevItem.OffsetHor)) + ((m_RtL) ? item.OffsetHor : -item.OffsetHor);

                            if ((m_RtL) ? item.Pos + atm > localEnd : item.Pos + atm < localEnd)
                                item.Pack.transform.localPosition += new Vector3(atm, 0f);
                            else
                                item.Pack.transform.localPosition = new Vector3(localEnd, 0f);
                            break;
                    }
                    item.UpdatePos();
                }
            }
            else
            {
                for (int i = 0; i < m_items.Count; i++)
                {
                    var item = m_items[i];

                    #region Raycasts
                    m_check0 = Physics2D.Raycast(
                        (Vector2)item.Pack.transform.position + new Vector2(((m_RtL) ? -item.OffsetHor : item.OffsetHor) * 1.01f, 0f),
                        new Vector2(m_dirNSpeed, 0),
                        Mathf.Abs(atm), m_checkMask);

                    m_check1 = Physics2D.Raycast(
                        (Vector2)item.Pack.transform.position + new Vector2(((m_RtL) ? -item.OffsetHor : item.OffsetHor) * 1.01f, item.OffsetVer),
                        new Vector2(m_dirNSpeed, 0),
                        Mathf.Abs(atm), m_checkMask);

                    m_check2 = Physics2D.Raycast(
                        (Vector2)item.Pack.transform.position + new Vector2(((m_RtL) ? -item.OffsetHor : item.OffsetHor) * 1.01f, -item.OffsetVer),
                        new Vector2(m_dirNSpeed, 0),
                        Mathf.Abs(atm), m_checkMask);
                    #endregion

                    m_hasObst = m_check1 || m_check2 || m_check0;

                    switch (i)
                    {
                        case 0:
                            if ((m_RtL) ? item.Pos + atm > m_end : item.Pos + atm < m_end)
                            {
                                if (!m_hasObst)
                                    item.Pack.transform.localPosition += new Vector3(atm, 0f);
                            }
                            else if (!m_hasObst)
                            {
                                item.Pack.transform.localPosition = new Vector3(m_end, 0f);
                            }
                            break;

                        default:

                            var prevItem = m_items[i - 1];
                            float localEnd = (prevItem.Pos + ((m_RtL) ? prevItem.OffsetHor : -prevItem.OffsetHor)) + ((m_RtL) ? item.OffsetHor : -item.OffsetHor);

                            if ((m_RtL) ? item.Pos + atm > localEnd : item.Pos + atm < localEnd)
                            {
                                if (!m_hasObst)
                                    item.Pack.transform.localPosition += new Vector3(atm, 0f);
                            }
                            else if (!m_hasObst)
                            {
                                item.Pack.transform.localPosition = new Vector3(localEnd, 0f);
                            }
                            break;
                    }
                    item.UpdatePos();
                }

            }
        }
    }
    public override bool Work(Package package)
    {
        package.RemoveCallback += Remove;
        package.Place(transform);

        var temp = MathF.Abs(package.transform.rotation.eulerAngles.z % 180);
        bool tempRot = temp > 45f && temp < 135f;

        package.transform.position = new Vector2(package.transform.position.x, transform.position.y);
        //package.transform.rotation = Quaternion.Euler(0f,0f,(tempRot) ? 90f : 0f);

        m_items.Add(new() { Pack = package, Pos = package.transform.localPosition.x,
            OffsetHor = ((tempRot) ? package.Data.Size.y: package.Data.Size.x)/2,
            OffsetVer = ((tempRot) ? package.Data.Size.x: package.Data.Size.y)/2
        });

        return true;
    }
    public void AddToEnd(Package package)
    {
        package.RemoveCallback += Remove;
        package.Place2(transform);

        package.transform.position = new Vector2(package.transform.position.x, transform.position.y);
        package.transform.rotation = Quaternion.identity;

        m_items.Add(new()
        {
            Pack = package,
            Pos = m_start,
            OffsetHor = (package.Data.Size.x) / 2,
            OffsetVer = (package.Data.Size.y) / 2
        });
    }
    private void Remove(Package package)
    {
        lock (m_lock)
        {
            m_items.Remove(m_items.Find(x => x.Pack == package));
            package.RemoveCallback -= Remove;
        }
    }
}
