using System;
using UnityEngine;

public class Palet : WorkerBase
{
    public Vector2 Size;
    public override bool Work(Package package)
    {
        var temp = MathF.Abs(package.transform.rotation.eulerAngles.z%180);
        bool tempRot = temp > 45f && temp < 135f;
        Vector2 temp_pos;

        if (tempRot)
            temp_pos = new Vector3(SnapToGrid(package.transform.position.x, package.Data.Size.y % 2 == 0), SnapToGrid(package.transform.position.y, package.Data.Size.x % 2 == 0));
        else
            temp_pos = new Vector3(SnapToGrid(package.transform.position.x, package.Data.Size.x % 2 == 0), SnapToGrid(package.transform.position.y, package.Data.Size.y % 2 == 0));

        Debug.Log($"Pos{package.transform.position} Temp{temp_pos}");

        if (tempRot) {
            if (!IsInZone(new Vector2(temp_pos.x + package.Data.Size.y/2, temp_pos.y + package.Data.Size.x / 2)) ||
                !IsInZone(new Vector2(temp_pos.x + package.Data.Size.y/2, temp_pos.y - package.Data.Size.x / 2)) ||
                !IsInZone(new Vector2(temp_pos.x - package.Data.Size.y/2, temp_pos.y + package.Data.Size.x / 2)) ||
                !IsInZone(new Vector2(temp_pos.x - package.Data.Size.y/2, temp_pos.y - package.Data.Size.x / 2)))
                return false;
        } else {
            if(!IsInZone(new Vector2(temp_pos.x + package.Data.Size.x / 2, temp_pos.y + package.Data.Size.y / 2)) ||
               !IsInZone(new Vector2(temp_pos.x + package.Data.Size.x / 2, temp_pos.y - package.Data.Size.y / 2)) ||
               !IsInZone(new Vector2(temp_pos.x - package.Data.Size.x / 2, temp_pos.y + package.Data.Size.y / 2)) ||
               !IsInZone(new Vector2(temp_pos.x - package.Data.Size.x / 2, temp_pos.y - package.Data.Size.y / 2)))
                return false;
        }
        
        package.transform.position = temp_pos;
        package.transform.rotation = Quaternion.Euler(0f,0f,90 * MathF.Round(MathF.Abs(package.transform.rotation.eulerAngles.z)/90,0));

        package.RemoveCallback += Remove;
        package.Place(transform);
        
        return true;
    }

    private bool IsInZone(Vector2 point) => (point.x >= transform.position.x - (Size.x / 2) && point.x <= transform.position.x + (Size.x / 2)) && (point.y >= transform.position.y - (Size.y / 2) && point.y <= transform.position.y + (Size.y / 2));

    private void Remove(Package package)
    {

        package.RemoveCallback -= Remove;
    }
}
