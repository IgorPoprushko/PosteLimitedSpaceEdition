using UnityEngine;

public abstract class WorkerBase: MonoBehaviour
{
    public abstract bool Work(Package package);

    public bool UserCanUse { get; protected set; } = true;

    protected float SnapToGrid(float p_value, bool p_toGrid)
    {
        return (p_toGrid) ? Mathf.RoundToInt(p_value) :
            (Mathf.Ceil(p_value) + Mathf.Floor(p_value)) / 2;
    }
}