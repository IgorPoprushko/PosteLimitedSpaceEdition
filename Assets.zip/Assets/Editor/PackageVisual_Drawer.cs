//using UnityEngine;
//using System.Collections;
//using UnityEditor;

//[CustomEditor(typeof(PackageVisual))]
//public class PackageVisualDrawer : Editor
//{
//    private const string path = "Assets/Resources/ScriptableObjects/Packages/";

//    private string m_name = "Package_01";

//    public override void OnInspectorGUI()
//    {
//        DrawDefaultInspector();

//        GUILayout.Space(EditorGUIUtility.singleLineHeight);

//        GUILayout.BeginHorizontal();
//        GUILayout.Label("File name:");
//        m_name = GUILayout.TextField(m_name);
//        GUILayout.EndHorizontal();

//        if (GUILayout.Button("Save as new asset"))
//        {
//            if (string.IsNullOrEmpty(m_name))
//            {
//                Debug.LogError($"Name is required field.");
//            }
//            if (string.IsNullOrEmpty(AssetDatabase.AssetPathToGUID(path + $"{m_name}.asset")))
//            {
//                PackageSO example = CreateInstance<PackageSO>();
//                //
//                AssetDatabase.CreateAsset(example, path + $"{m_name}.asset");

//                Debug.Log($"Asset {m_name} was created;");
//            }
//            else
//            {
//                Debug.LogError($"Asset {m_name} already exists.");
//            }
//        }
//    }
//}
